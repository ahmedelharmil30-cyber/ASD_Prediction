"""Small shared UI helpers so every page looks consistent."""
from __future__ import annotations

import streamlit as st

BRAND = "ASD Prediction Platform"

CUSTOM_CSS = """
<style>
.block-container { padding-top: 2rem; padding-bottom: 3rem; max-width: 900px; }
.asd-badge {
    display: inline-block; padding: 4px 12px; border-radius: 999px;
    background: #EEF2FF; color: #4338CA; font-size: 0.75rem; font-weight: 600;
    margin-bottom: 0.75rem;
}
.asd-card {
    border: 1px solid #E5E7EB; border-radius: 14px; padding: 1.25rem 1.5rem;
    background: #FFFFFF; margin-bottom: 1rem;
}
.asd-recommend {
    border-radius: 14px; padding: 1rem 1.25rem; margin-top: 0.75rem;
    background: #FFFBEB; border: 1px solid #FDE68A; color: #92400E; font-size: 0.95rem;
}
.asd-footer { color: #9CA3AF; font-size: 0.8rem; margin-top: 2rem; text-align: center; }
</style>
"""


def inject_base_style() -> None:
    st.set_page_config(
        page_title=BRAND,
        page_icon="🧩",
        layout="centered",
        initial_sidebar_state="expanded",
    )
    st.markdown(CUSTOM_CSS, unsafe_allow_html=True)


def badge(text: str) -> None:
    st.markdown(f'<span class="asd-badge">{text}</span>', unsafe_allow_html=True)


def footer() -> None:
    st.markdown(
        '<div class="asd-footer">Screening tool only — not a diagnosis. '
        "Consult a licensed professional for a formal evaluation.</div>",
        unsafe_allow_html=True,
    )


def gauge_color(risk_pct: float) -> str:
    if risk_pct >= 75:
        return "#DC2626"  # red
    if risk_pct >= 35:
        return "#D97706"  # amber
    return "#16A34A"  # green


def render_gauge(risk_pct: float, label: str = "Predicted ASD likelihood") -> None:
    """Simple gauge built with an SVG arc — no extra chart dependency needed."""
    color = gauge_color(risk_pct)
    pct = max(0.0, min(100.0, risk_pct))
    angle = 180 * (pct / 100.0)
    import math

    cx, cy, r = 100, 100, 80
    x = cx - r * math.cos(math.radians(angle))
    y = cy - r * math.sin(math.radians(angle))
    large_arc = 1 if angle > 180 else 0

    svg = f"""
    <svg viewBox="0 0 200 115" xmlns="http://www.w3.org/2000/svg" style="width:100%;max-width:280px;margin:auto;display:block;">
      <path d="M 20 100 A 80 80 0 0 1 180 100" fill="none" stroke="#E5E7EB" stroke-width="16" stroke-linecap="round"/>
      <path d="M 20 100 A 80 80 0 {large_arc} 1 {x:.1f} {y:.1f}" fill="none" stroke="{color}" stroke-width="16" stroke-linecap="round"/>
      <text x="100" y="95" text-anchor="middle" font-size="28" font-weight="700" fill="#111827">{pct:.1f}%</text>
    </svg>
    """
    st.markdown(svg, unsafe_allow_html=True)
    st.markdown(f"<p style='text-align:center;color:#6B7280;'>{label}</p>", unsafe_allow_html=True)
